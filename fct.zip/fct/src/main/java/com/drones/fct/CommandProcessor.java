// package com.drones.fct;

// public class CommandProcessor {

// private final GridManager gridManager;

// public CommandProcessor(GridManager gridManager) {
// this.gridManager = gridManager;
// }

// public void processCommands() {
// System.out.println("Procesando comandos...");
// }
// }
