package com.drones.fct.dto;

import com.drones.fct.domain.Orientation;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateDroneRequest {

  @NotNull
  private Long matrixId;

  @NotBlank
  private String name;

  @NotBlank
  private String model;

  @NotNull
  private Integer x;

  @NotNull
  private Integer y;

  @NotNull
  private Orientation orientation;
}