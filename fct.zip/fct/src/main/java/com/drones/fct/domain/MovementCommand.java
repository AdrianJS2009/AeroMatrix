package com.drones.fct.domain;

public enum MovementCommand {
  TURN_LEFT,
  TURN_RIGHT,
  MOVE_FORWARD
}