package com.drones.fct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FctApplication {

	public static void main(String[] args) {
		SpringApplication.run(FctApplication.class, args);
	}
}
