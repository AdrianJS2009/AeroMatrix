package com.drones.fct.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateMatrixRequest {

  @NotNull
  @Min(1)
  private Integer maxX;

  @NotNull
  @Min(1)
  private Integer maxY;
}