package com.drones.fct.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drones.fct.domain.Drone;
import com.drones.fct.dto.CreateDroneRequest;
import com.drones.fct.dto.DroneDto;
import com.drones.fct.service.DroneService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/drones")
@RequiredArgsConstructor
public class DroneController {

  private final DroneService droneService;

  @Operation(summary = "Crear un dron")
  @PostMapping
  public ResponseEntity<DroneDto> createDrone(@RequestBody CreateDroneRequest request) {
    Drone drone = droneService.createDrone(
        request.getMatrixId(),
        request.getName(),
        request.getModel(),
        request.getX(),
        request.getY(),
        request.getOrientation());
    return new ResponseEntity<>(toDto(drone), HttpStatus.CREATED);
  }

  @Operation(summary = "Obtener dron por ID")
  @GetMapping("/{droneId}")
  public DroneDto getDrone(@PathVariable Long droneId) {
    Drone drone = droneService.getDrone(droneId);
    return toDto(drone);
  }

  @Operation(summary = "Actualizar un dron")
  @PutMapping("/{droneId}")
  public DroneDto updateDrone(
      @PathVariable Long droneId,
      @RequestBody CreateDroneRequest request) {
    Drone drone = droneService.updateDrone(
        droneId,
        request.getName(),
        request.getModel(),
        request.getX(),
        request.getY(),
        request.getOrientation());
    return toDto(drone);
  }

  @Operation(summary = "Eliminar un dron")
  @DeleteMapping("/{droneId}")
  public ResponseEntity<Void> deleteDrone(@PathVariable Long droneId) {
    droneService.deleteDrone(droneId);
    return ResponseEntity.noContent().build();
  }

  private DroneDto toDto(Drone drone) {
    DroneDto dto = new DroneDto();
    dto.setId(drone.getId());
    dto.setName(drone.getName());
    dto.setModel(drone.getModel());
    dto.setX(drone.getX());
    dto.setY(drone.getY());
    dto.setOrientation(drone.getOrientation());
    dto.setMatrixId(drone.getMatrix().getId());
    return dto;
  }
}