package com.drones.fct.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.drones.fct.domain.Drone;
import com.drones.fct.dto.CommandsRequest;
import com.drones.fct.dto.DroneDto;
import com.drones.fct.service.FlightService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/flights")
@RequiredArgsConstructor
public class FlightController {

  private final FlightService flightService;

  @Operation(summary = "Ejecutar una secuencia de órdenes en un dron")
  @PostMapping("/drone/{droneId}/commands")
  public DroneDto executeCommands(@PathVariable Long droneId, @RequestBody CommandsRequest request) {
    Drone drone = flightService.executeCommands(droneId, request.getCommands());
    return toDto(drone);
  }

  @Operation(summary = "Ejecutar secuencias de órdenes en varios drones (en orden)")
  @PostMapping("/drones/commands")
  public void executeCommandsInSequence(
      @RequestParam List<Long> droneIds,
      @RequestBody CommandsRequest request) {
    flightService.executeCommandsInSequence(droneIds, request.getCommands());
  }

  private DroneDto toDto(Drone drone) {
    DroneDto dto = new DroneDto();
    dto.setId(drone.getId());
    dto.setName(drone.getName());
    dto.setModel(drone.getModel());
    dto.setX(drone.getX());
    dto.setY(drone.getY());
    dto.setOrientation(drone.getOrientation());
    dto.setMatrixId(drone.getMatrix().getId());
    return dto;
  }
}