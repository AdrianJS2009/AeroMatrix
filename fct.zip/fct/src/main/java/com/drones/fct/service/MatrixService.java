package com.drones.fct.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.drones.fct.domain.Matrix;
import com.drones.fct.exception.NotFoundException;
import com.drones.fct.repository.MatrixRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class MatrixService {

  private final MatrixRepository matrixRepository;

  public Matrix createMatrix(Integer maxX, Integer maxY) {
    if (maxX <= 0 || maxY <= 0) {
      throw new IllegalArgumentException("Dimensiones de la matriz inválidas");
    }
    Matrix matrix = Matrix.builder()
        .maxX(maxX)
        .maxY(maxY)
        .build();
    return matrixRepository.save(matrix);
  }

  public Matrix updateMatrix(Long matrixId, Integer maxX, Integer maxY) {
    Matrix matrix = matrixRepository.findById(matrixId)
        .orElseThrow(() -> new NotFoundException("Matriz no encontrada"));

    if (maxX <= 0 || maxY <= 0) {
      throw new IllegalArgumentException("Dimensiones de la matriz inválidas");
    }

    matrix.setMaxX(maxX);
    matrix.setMaxY(maxY);

    return matrixRepository.save(matrix);
  }

  public Matrix getMatrix(Long matrixId) {
    return matrixRepository.findById(matrixId)
        .orElseThrow(() -> new NotFoundException("Matriz no encontrada"));
  }

  public void deleteMatrix(Long matrixId) {
    Matrix matrix = matrixRepository.findById(matrixId)
        .orElseThrow(() -> new NotFoundException("Matriz no encontrada"));
    matrixRepository.delete(matrix);
  }
}