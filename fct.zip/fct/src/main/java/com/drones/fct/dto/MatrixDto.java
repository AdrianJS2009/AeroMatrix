package com.drones.fct.dto;

import lombok.Data;

@Data
public class MatrixDto {
  private Long id;
  private Integer maxX;
  private Integer maxY;
}