// package com.drones.fct;

// public class GridManager {

// public void placeDrone(int x, int y, char orientation) {
// System.out.println("Colocando dron en (" + x + ", " + y + ") con orientación
// " + orientation);
// }

// public void drawGrid() {
// System.out.println("Dibujando la cuadrícula...");
// }
// }
