package com.drones.fct.domain;

public enum Orientation {
  N, S, E, O
}