package com.drones.fct.dto;

import java.util.List;

import com.drones.fct.domain.MovementCommand;

import lombok.Data;

@Data
public class CommandsRequest {
  private List<MovementCommand> commands;
}