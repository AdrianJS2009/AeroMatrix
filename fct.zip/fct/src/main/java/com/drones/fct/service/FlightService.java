package com.drones.fct.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.drones.fct.domain.Drone;
import com.drones.fct.domain.Matrix;
import com.drones.fct.domain.MovementCommand;
import com.drones.fct.domain.Orientation;
import com.drones.fct.exception.ConflictException;
import com.drones.fct.exception.NotFoundException;
import com.drones.fct.repository.DroneRepository;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class FlightService {

  private final DroneRepository droneRepository;

  public Drone executeCommands(Long droneId, List<MovementCommand> commands) {
    Drone drone = droneRepository.findById(droneId)
        .orElseThrow(() -> new NotFoundException("Drone no encontrado"));

    for (MovementCommand cmd : commands) {
      switch (cmd) {
        case TURN_LEFT -> turnLeft(drone);
        case TURN_RIGHT -> turnRight(drone);
        case MOVE_FORWARD -> moveForward(drone);
        default -> throw new IllegalArgumentException("Comando no soportado: " + cmd);
      }
    }

    return drone; // Gracias a @Transactional, se guardan cambios al final
  }

  public void executeCommandsInSequence(List<Long> droneIds, List<MovementCommand> commands) {
    // Se ejecutan los comandos en el orden dado para cada dron
    // Podrías personalizar la lógica según el enunciado
    for (Long droneId : droneIds) {
      executeCommands(droneId, commands);
    }
  }

  private void turnLeft(Drone drone) {
    Orientation current = drone.getOrientation();
    switch (current) {
      case N -> drone.setOrientation(Orientation.O);
      case O -> drone.setOrientation(Orientation.S);
      case S -> drone.setOrientation(Orientation.E);
      case E -> drone.setOrientation(Orientation.N);
    }
  }

  private void turnRight(Drone drone) {
    Orientation current = drone.getOrientation();
    switch (current) {
      case N -> drone.setOrientation(Orientation.E);
      case E -> drone.setOrientation(Orientation.S);
      case S -> drone.setOrientation(Orientation.O);
      case O -> drone.setOrientation(Orientation.N);
    }
  }

  private void moveForward(Drone drone) {
    int x = drone.getX();
    int y = drone.getY();
    Matrix matrix = drone.getMatrix();

    switch (drone.getOrientation()) {
      case N -> y++;
      case S -> y--;
      case E -> x++;
      case O -> x--;
    }

    // Validar límites
    if (x < 0 || x > matrix.getMaxX() || y < 0 || y > matrix.getMaxY()) {
      throw new ConflictException("El dron se saldría de los límites de la matriz");
    }

    // Validar colisión
    Optional<Drone> other = droneRepository.findByXAndYAndMatrixId(x, y, matrix.getId());
    if (other.isPresent() && !other.get().getId().equals(drone.getId())) {
      throw new ConflictException("Colisión detectada con el dron ID " + other.get().getId());
    }

    // Actualizar posición
    drone.setX(x);
    drone.setY(y);
  }
}