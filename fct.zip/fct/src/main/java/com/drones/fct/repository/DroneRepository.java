package com.drones.fct.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.drones.fct.domain.Drone;

public interface DroneRepository extends JpaRepository<Drone, Long> {

  Optional<Drone> findByXAndYAndMatrixId(Integer x, Integer y, Long matrixId);

  List<Drone> findByMatrixId(Long matrixId);

}