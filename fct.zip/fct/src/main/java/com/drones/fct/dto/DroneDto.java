package com.drones.fct.dto;

import com.drones.fct.domain.Orientation;

import lombok.Data;

@Data
public class DroneDto {
  private Long id;
  private String name;
  private String model;
  private Integer x;
  private Integer y;
  private Orientation orientation;
  private Long matrixId;
}